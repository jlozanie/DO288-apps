package com.sefin.techos.techosspring;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sefin.techos.negocio.InstObjeto;
import com.sefin.techos.negocio.Institucion;

@RestController
public class TechoServicio {
	
	@RequestMapping("/saludo")
	public String hola() {
		return "Hola desde aplicacion Techos";
	}

	@RequestMapping(value="/sefin/api/techos", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public InstObjeto getObjTecho(@RequestBody Institucion inst) {
		InstObjeto insObj = new InstObjeto(inst, 12000, "Sueldos y Salarios");
		return insObj;
	}

	
}
