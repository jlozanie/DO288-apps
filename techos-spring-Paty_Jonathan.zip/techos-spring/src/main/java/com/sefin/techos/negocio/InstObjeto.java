package com.sefin.techos.negocio;

public class InstObjeto {
	Institucion inst;
	int codigoObj;
	String nombObj;
	double techoObj;
	double totGasto;
	
	public InstObjeto(Institucion inst, int Obj, String nomObj) {
		// TODO Auto-generated constructor stub
		this.inst = inst;
		this.techoObj = inst.getMonto() * 0.25;
		this.totGasto = inst.getMonto() - this.techoObj;
		this.codigoObj = Obj;
		this.nombObj = nomObj;
	}

	public Institucion getInst() {
		return inst;
	}

	public void setInst(Institucion inst) {
		this.inst = inst;
	}

	public int getCodigoObj() {
		return codigoObj;
	}

	public void setCodigoObj(int codigoObj) {
		this.codigoObj = codigoObj;
	}

	public String getNombObj() {
		return nombObj;
	}

	public void setNombObj(String nombObj) {
		this.nombObj = nombObj;
	}

	public double getTechoObj() {
		return techoObj;
	}

	public void setTechoObj(double techoObj) {
		this.techoObj = techoObj;
	}
	

}
